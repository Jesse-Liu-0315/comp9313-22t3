from pyspark import SparkContext, SparkConf
import sys

class Problem:  

    def run(self, inputPath, outputPath):

        conf = SparkConf().setAppName("project2_rdd")
        sc = SparkContext(conf=conf)
        fileRDD = sc.textFile(inputPath)

        #provide your code here

        rankRDD.saveAsTextFile(outputPath)
        sc.stop()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Wrong arguments")
        sys.exit(-1)
    Problem().run(sys.argv[1], sys.argv[2])